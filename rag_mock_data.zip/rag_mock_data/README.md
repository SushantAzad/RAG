# RAG Mock Dataset

This is a synthetic dataset generated for testing a Retrieval Augmented Generation (RAG) pipeline. All content is fictional. It's designed to mimic a real company's internal knowledge base, with variety across topics, file formats, document length, and directory depth, so you can test chunking, embedding, retrieval, and citation behavior.

## Structure

```
rag_mock_data/
├── hr/
│   ├── policies/
│   │   ├── remote_work_policy.md
│   │   └── paid_time_off.md
│   ├── benefits/
│   │   ├── health_insurance_guide.md
│   │   └── retirement_401k.txt
│   └── employee_directory_sample.json
├── engineering/
│   ├── architecture/
│   │   ├── system_architecture_overview.md
│   │   └── adr_003_message_queue_choice.md
│   └── runbooks/
│       ├── incident_response_runbook.md
│       ├── database_migration_runbook.md
│       └── oncall/
│           └── escalation_matrix.md
├── product/
│   └── specs/
│       ├── saved_carts_feature_spec.md
│       └── dark_mode_spec.txt
├── legal/
│   └── contracts/
│       ├── vendor_service_agreement_summary.md
│       └── mutual_nda_template.txt
├── faq/
│   ├── general_faq.md
│   └── api_faq.md
└── finance/
    └── reports/
        └── q2_2026_summary.md
```

## What this is good for testing

- **Chunking strategy**: documents range from short FAQs (a few hundred words) to longer policy and architecture docs (800+ words), and include tables, numbered lists, and markdown headers.
- **Cross document retrieval**: some documents reference each other (the finance report references the saved carts spec, the escalation matrix references the incident runbook), useful for testing multi hop or comparison queries.
- **Mixed file types**: markdown, plain text, and JSON are all present, so you can test format specific parsing.
- **Directory depth**: most documents sit two levels deep, but `escalation_matrix.md` sits three levels deep to test recursive directory traversal.
- **Domain diversity**: HR, engineering, product, legal, and finance content, useful for testing topic based retrieval and filtering by metadata like department or file path.

## Suggested test queries

- "How much PTO do I get after 5 years?" (tests table extraction, hr/policies/paid_time_off.md)
- "What's the company's 401k match?" (tests numeric reasoning, hr/benefits/retirement_401k.txt)
- "Why did we choose Kafka over RabbitMQ?" (tests ADR retrieval, engineering/architecture/adr_003_message_queue_choice.md)
- "What's the escalation path for a security incident?" (tests nested directory retrieval, engineering/runbooks/oncall/escalation_matrix.md)
- "What was the revenue impact of the saved carts feature?" (tests cross document linkage between finance and product docs)
- "What's the SLA credit if uptime drops below 95%?" (tests table lookup in a legal document)
